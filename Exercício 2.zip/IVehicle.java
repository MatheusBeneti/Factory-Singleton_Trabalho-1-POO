/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package my.trabalho1ex2_poo_matheusbeneti;

/**
 *
 * @author mathe
 */
public interface IVehicle {
    void start();
    void stop();
    void drive();
}
